let words = [];
let timer = 60,
  interval;
let correctWords = 0;
let startTime;
let userInput = document.getElementById("typing-input");
let textContainer = document.getElementById("text-container");
let wpmDisplay = document.getElementById("wpm");
let cpmDisplay = document.getElementById("cpm");
let accuracyDisplay = document.getElementById("accuracy");
let testDurationSelect = document.getElementById("test-duration");
let popup = document.getElementById("popup");
let popupContent = document.getElementById("popup-content");
let accuracy;
let modal;

document.addEventListener("DOMContentLoaded", function () {
  let myModalEl = document.getElementById("myModal");
  let myModal = new bootstrap.Modal(myModalEl); // Store modal instance globally
  modal = myModal;

  // Hide modal when needed
  function hideModal() {
    myModal.hide();
  }

  // Close modal and restart test on button click
  document
    .getElementById("restart-btn-modal")
    .addEventListener("click", function () {
      hideModal(); // Close modal
      resetTest(); // Restart the test
    });
});

// Load words based on selected duration
function loadWords() {
  let duration = parseInt(testDurationSelect.value);
  let fileName =
    duration === 60
      ? "words1.json"
      : duration === 180
      ? "words3.json"
      : "words5.json";

  fetch(fileName)
    .then((response) => response.json())
    .then((data) => {
      words = data;
      loadNewText();
    })
    .catch((error) => console.error("Error loading words:", error));
}

// Load a new random text
function loadNewText() {
  if (words.length === 0) {
    console.error("No words loaded!");
    return;
  }

  let randomIndex = Math.floor(Math.random() * words.length);
  let text = words[randomIndex];

  textContainer.innerHTML = text
    .split("")
    .map((char, index) => `<span id="char-${index}">${char}</span>`)
    .join("");
}

// Reset test settings
function resetTest() {
  clearInterval(interval);
  userInput.value = "";
  userInput.disabled = false;
  correctWords = 0;
  accuracy = 0;
  timer = 0;
  startTime = null;
  wpmDisplay.innerText = "0 words/min";
  cpmDisplay.innerText = "0 chars/min";
  accuracyDisplay.innerText = "0% accuracy";

  timer = parseInt(testDurationSelect.value);
  document.getElementById("timer").innerText = `${timer} seconds`;
  if (words.length === 0) {
    loadWords(); // Ensure words are loaded before resetting
  } else {
    loadNewText();
  }
}

// Update timer display and restart test
function updateTimer() {
  userInput.value = "";
  timer = parseInt(testDurationSelect.value);
  document.getElementById("timer").innerText = `${timer} seconds`;
  clearInterval(interval);
  loadWords();
}

// Detect input changes
userInput.addEventListener("input", () => {
  let chars = textContainer.querySelectorAll("span");
  let typedText = userInput.value.split("");

  if (!startTime) {
    startTime = new Date();
    startTimer();
  }

  let correctChars = 0;
  let totalChars = typedText.length;

  // Check each character for correctness (optional if you only care about input length)
  chars.forEach((char, index) => {
    if (typedText[index] === undefined) {
      char.classList.remove("correct", "incorrect");
    } else if (typedText[index] === char.innerText) {
      char.classList.add("correct");
      char.classList.remove("incorrect");
      correctChars++;
    } else {
      char.classList.add("incorrect");
      char.classList.remove("correct");
    }
  });

  correctWords = Math.floor(correctChars / 5);
  accuracy = totalChars ? Math.round((correctChars / totalChars) * 100) : 0;
  accuracyDisplay.innerText = `${accuracy}% accuracy`;

  // When the user has typed all characters, show the result popup
  if (typedText.length === chars.length) {
    userInput.disabled = true;
    clearInterval(interval);

    // Calculate elapsed time
    let elapsedTime = (new Date() - startTime) / 1000;
    let wpm = Math.round((correctWords / elapsedTime) * 60);
    let cpm = Math.round((userInput.value.length / elapsedTime) * 60);
    let duration = Math.round(elapsedTime);
    showPopup(wpm, cpm, accuracy, duration);
  }
});

// Timer functionality
function startTimer() {
  clearInterval(interval);

  interval = setInterval(() => {
    let elapsedTime = (new Date() - startTime) / 1000;
    let wpm = Math.round((correctWords / elapsedTime) * 60);
    let cpm = Math.round((userInput.value.length / elapsedTime) * 60);

    wpmDisplay.innerText = `${isNaN(wpm) ? 0 : wpm} words/min`;
    cpmDisplay.innerText = `${isNaN(cpm) ? 0 : cpm} chars/min`;

    // when timer is over show user result
    if (timer <= 0) {
      userInput.disabled = true;
      clearInterval(interval);
      let duration = parseInt(testDurationSelect.value);
      showPopup(wpm, cpm, accuracy, duration);
    }

    document.getElementById("timer").innerText = `${timer--} seconds`;
  }, 1000);
}

function showPopup(wpm, cpm, accuracy, duration) {
  document.getElementById("popup-wpm").textContent = wpm;
  document.getElementById("popup-cpm").textContent = cpm;
  document.getElementById("popup-accuracy").textContent = accuracy;
  document.getElementById("popup-time").textContent = duration + " seconds";
  modal.show();
}

// Restart button event
document.getElementById("restart").addEventListener("click", resetTest);

// Update timer and restart test on duration change
testDurationSelect.addEventListener("change", updateTimer);

// Load words when the page is ready
document.addEventListener("DOMContentLoaded", loadWords);
